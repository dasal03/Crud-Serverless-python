async function postData(url = "", data = {}) {
  const response = await fetch(url, {
    method: "POST",
    mode: "cors",
    cache: "no-cache",
    credentials: "same-origin",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  });
  return response.json();
}

const data = {
  producto: "agua",
  valor: "2000",
  modulo: "productos",
};

postData("https://qyrmwjgt2k.execute-api.us-east-1.amazonaws.com/", data)
  .then((data) => {
    console.log(data);
  })
  .catch((err) => {
    console.log(err);
  });
